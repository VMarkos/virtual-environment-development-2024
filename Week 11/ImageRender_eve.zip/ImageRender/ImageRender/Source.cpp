#include <iostream> // This is used to print things on screen / streams
#include <fstream> // This is used to read from / write to files
#include <sstream> // This is used to read strings as streams
#include <string> // To use strings
using namespace std;

void flipX(string infile, string outfile) {
    // infile (unedited image)
    ifstream img_file; // `ifstream` by default reads a file;
    img_file.open(infile, ios::in);

    // outfile (flipped image)
    ofstream out_file;
    out_file.open(outfile, ios::out);

    int i = 0, j = 0; // This is a line counter
    string line; // This will keep each line of the file
    int img_width, img_height, max_color, r, g, b;
    string img_header;
    int* img_pixels = new int[3 * img_width * img_height]; // Dynamic memory allocation
    img_pixels = nullptr; // To prevent Visual C++ from complaining...
    while (getline(img_file, line)) {
        istringstream iss(line); // this 'converts' the string `line` to a string stream
        if (i == 0) { // P3
            iss >> img_header; // "read" the contents of iss into img_header
            out_file << img_header << '\n'; // write img_header to out_file
        } else if (i == 1) { // width height
            iss >> img_width >> img_height; // read image dimensions
            out_file << img_width << ' ' << img_height << '\n';
        } else if (i == 2) { // maxcolor
            iss >> max_color;
            out_file << max_color << '\n';
        } else { // Pixels (one per line)
            iss >> r >> g >> b; // read an RGB pixel
            *(img_pixels + j++) = r;
            *(img_pixels + j++) = g;
            *(img_pixels + j++) = b;
        }
        i++;
    }
    img_file.close(); // We have nothing to read...

    int k;
    // Write pixels starting from last row to first
    for (int i = img_height - 1; i >= 0; i--) {
        for (int j = 0; j < img_width * 3; j += 3) { // REMARK: Each line has img_width pixels
        // BUT img_width * 3 integers!
            k = i * img_width * 3 + j;
            r = *(img_pixels + k);
            g = *(img_pixels + k + 1);
            b = *(img_pixels + k + 2);
            out_file << r << ' ' << g << ' ' << b << '\n';
        }
    }
    delete img_pixels; // Deallocate memory;
    out_file.close();
}

/*
A few words on 2D arrays in C++

1. 2D arrays DO NOT EXIST!
2. The most usual way to implement a 2D array is to use an array which contains arrays.
3. This creates a pointer (the master array) which contains pointers to the minor arrays.
4. So, this means that, whenever we want to create such an array we have to allocate memory for 
   each 'row' separately and for the master array of pointers as well.
5. So, this also means that we have to delete all this memory once we are done!
6. Another alternative is to flattern such arrays to 1D arrays.

Some remarks:
1. The "pointers to pointers" approach is more troublesome when it comes to memory management.
2. The 1d approach is easier when it comes to memory management.
3. The "pointers to pointers" approach does not required that many consequtive memory addresses
   since each "row" is kept at a different place in memory, while the 1d approach stores 
   everything in consequtive memory locations.
*/

int init_image() {
    // Image width and height in pixels
    int image_width = 256;
    int image_height = 256;

    // Max color value
    int max_color = 255;

    // Open a file stream to write the image into:
    ofstream img_file; // Declare a file stream variable
    img_file.open("sample_001.ppm", ios::out); // Open a file stream, i.e., open a file

    // Render the image (into a file, eventually)
    img_file << "P3\n" << image_width << ' ' << image_height << '\n' << max_color << '\n';
    /* Format:

    ```ppm
    P3
    <width> <height>
    <max colors>
    ```

    In the above, width and height are the image width and height in pixels and <max colors> is the
    maximum value for our RGB values within each pixel.
    */

    for (int i = 0; i < image_height; i++) {
        for (int j = 0; j < image_width; j++) {
            // RGB values as floats numbers in [0,1]
            double r = 0.0;
            double g = double(i) / (image_height - 1); // `-1` since i <- {0,1,...,255}
            double b = double(j) / (image_width - 1);
            /*
            * Rescaling to 255 * 255:
            * Assume you have an image with dimensions 1080 * 1080.
            * Then, i, j might range in {0,1,...,1079}.
            * To rescale them to an integer in {0,1,...,255} we can work as follows:
            *   1. Divide i by 1079, so i / 1079 is a float in [0,1]
            *   2. Multiply by 255, so int(i / 1079 * 255) is an int in {0,...,255}
            */

            // Integer RGB values, in {0,1,...,255}
            int ir = int(255.999 * r);
            int ig = int(255.999 * g);
            int ib = int(255.999 * b);

            /*
            * Old version:
            * 
            * ```cpp
            * int ir = int(255 * r); // This might not always work as expected;
            * int ig = int(255 * g); // This might not always work as expected;
            * int ib = int(255 * b); // This might not always work as expected;
            * ```
            * 
            * In the above, the only case a pixel gets 255 in some colour is if
            * `r` or `g` or `b` is exactly `1.0`. For all other values in {0,1,...,254}
            * we have more than one values of `r`, `g`, `b` where they might appear.
            * For example, for `r == 0.0`, then `ir == int(255 * 0) == 0`.
            * However, also for `r == 0.0038`, then `ir == int(255 * 0.0038) == 0`.
            */

            img_file << ir << ' ' << ig << ' ' << ib << '\n';
        }
    }

    // Write the image string into a file
    img_file.close(); // Close the file
    /*
    `fstream` offers access to both `ofstream` (output) and `ifstream` (input).
    When we declare a stream as `ofstream` we can write to that file by default (`ios::out`)
    When we declare a stream as `ifstream` we can write to that file by default (`ios::in`)
    */
    return 0;
}

int main() {
    flipX("sample_001.ppm", "x_flipped_001.ppm");
    return 0;
}