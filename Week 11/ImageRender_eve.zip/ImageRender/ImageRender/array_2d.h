// array_2d.h

template <typename T>
class array_2d {
    private:
        T** arr; // Pointer to pointers of type T
        int rows; // Number of rows
        int cols; // Number of columns
    public:
        array_2d(int, int); // This constructor takes two integers, rows and cols
        ~array_2d(); // Destructor for our class
        T get(int, int); // Get the element at row i and col j
        void set(int, int, T); // Set the element at row i and col j
        int get_rows() { return rows; } // Returns rows
        int get_cols() { return cols; } // Returns cols
};