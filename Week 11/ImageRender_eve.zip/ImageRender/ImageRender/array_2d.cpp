// array_2d.cpp
#include "array_2d.h"

template<typename T>
array_2d<T>::array_2d(int rows, int cols) {
    this->rows = rows; // Static memory allocation --> the compiler can deallocate this
    this->cols = cols; // Static memory allocation --> the compiler can deallocate this
    this->arr = new T*[rows];
    // if (this->arr == nullptr) {
    //     // throw exception!
    // }
    for (int i = 0; i < rows; i++) {
        this->arr[i] = new T[cols];
    }
}

template<typename T>
array_2d<T>::~array_2d() {
    // Deallocate any memory allocated with `new`
    for (int i = 0; i < this->rows; i++) {
        delete[] this->arr[i];
    }
    delete[] this->arr;
}

template<typename T>
T array_2d<T>::get(int i, int j) {
    return this->arr[i][j];
}

template<typename T>
void array_2d<T>::set(int i, int j, T x) {
    this->arr[i][j] = x;
}